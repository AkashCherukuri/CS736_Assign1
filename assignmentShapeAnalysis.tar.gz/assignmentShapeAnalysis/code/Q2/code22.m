function [aligned_points,shape_mean] = code22(nps,np,points)
[aligned_points,shape_mean]=code2(nps,np,points);
end